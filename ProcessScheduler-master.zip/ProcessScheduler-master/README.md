# ProcessScheduler
Implementação de um escalonador de tarefas para Time Sharing em uma máquina com um único núcleo de processador.
